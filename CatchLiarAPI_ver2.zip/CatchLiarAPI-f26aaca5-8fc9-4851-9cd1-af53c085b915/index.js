const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    console.log("Event received:", JSON.stringify(event));

    // POST 요청 처리 - 참가자 추가 및 상태 "active" 설정
    if (event.httpMethod === "POST" && event.resource === "/participants/add") {
        const { participantId } = JSON.parse(event.body);

        const params = {
            TableName: "CatchLiarParticipants",
            Item: {
                participantId,
                timestamp: Date.now(),
                status: "active", // 기본 상태를 active로 설정
            },
        };

        try {
            await dynamoDB.put(params).promise();
            console.log("Participant added successfully:", params.Item);
            return {
                statusCode: 200,
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*",
                },
                body: JSON.stringify({ message: "Participant added successfully!" }),
            };
        } catch (error) {
            console.error("Error adding participant:", error);
            return {
                statusCode: 500,
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*",
                },
                body: JSON.stringify({ error: error.message }),
            };
        }
    }
    
    // GET 요청 처리 - 현재 접속 중인 참가자 조회
    if (event.httpMethod === "GET" && event.resource === "/participants") {
        const scanParams = {
            TableName: "CatchLiarParticipants",
            FilterExpression: "#s = :status",
            ExpressionAttributeNames: { "#s": "status" },
            ExpressionAttributeValues: { ":status": "active" },
        };
    
        try {
            const data = await dynamoDB.scan(scanParams).promise();
            const participants = data.Items || [];
            return {
                statusCode: 200,
                headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({
                    count: participants.length,
                    participants: participants.map((p) => ({
                        participantId: p.participantId,
                    })),
                }),
            };
        } catch (error) {
            console.error("Error fetching participants:", error);
            return {
                statusCode: 500,
                headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({ error: "Failed to fetch participants." }),
            };
        }
    }
    
    if (event.httpMethod === "POST" && event.resource === "/participants/reset") {
        const scanParams = {
            TableName: "CatchLiarParticipants",
        };

        try {
            // 모든 항목을 가져와서 상태를 inactive로 변경
            const data = await dynamoDB.scan(scanParams).promise();
            const updatePromises = data.Items.map((item) => {
                const updateParams = {
                    TableName: "CatchLiarParticipants",
                    Key: { participantId: item.participantId },
                    UpdateExpression: "SET #s = :status",
                    ExpressionAttributeNames: { "#s": "status" },
                    ExpressionAttributeValues: { ":status": "inactive" },
                };
                return dynamoDB.update(updateParams).promise();
            });

            await Promise.all(updatePromises);
            console.log("All participants reset to inactive.");
            return {
                statusCode: 200,
                headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({ message: "All participants reset to inactive." }),
            };
        } catch (error) {
            console.error("Error resetting participants:", error);
            return {
                statusCode: 500,
                headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({ error: error.message }),
            };
        }
    }
    // Method Not Allowed 처리
    return {
        statusCode: 405,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ message: "Method Not Allowed" }),
    };
};
