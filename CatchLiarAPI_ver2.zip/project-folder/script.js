const addParticipantUrl = 'https://hvvpkbqa6a.execute-api.ap-northeast-2.amazonaws.com/prod/participants/add';
const getParticipantsUrl = 'https://hvvpkbqa6a.execute-api.ap-northeast-2.amazonaws.com/prod/participants';
const resetParticipantsUrl = 'https://hvvpkbqa6a.execute-api.ap-northeast-2.amazonaws.com/prod/participants/reset';

async function resetParticipants() {
    try {
        const response = await fetch(resetParticipantsUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
        });
        const data = await response.json();
        console.log(data.message);

        // 초기화 후 참가자 정보를 다시 가져오기
        fetchParticipants();
    } catch (error) {
        console.error('참가자 초기화 중 오류 발생:', error);
    }
}
// Reset 버튼 이벤트 등록
document.getElementById('reset-button').addEventListener('click', resetParticipants);

// 참가자 추가 요청
async function addParticipant() {
    try {
        const response = await fetch('https://hvvpkbqa6a.execute-api.ap-northeast-2.amazonaws.com/prod/participants/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ participantId: `user-${Date.now()}` }), // 고유 ID 생성
        });
        const data = await response.json();
        console.log(data.message);
    } catch (error) {
        console.error('참가자 추가 중 오류 발생:', error);
    }
}

// 현재 접속자 정보 가져오기
async function fetchParticipants() {
    try {
        const response = await fetch(getParticipantsUrl);
        const data = await response.json();

        document.getElementById('participant-count').innerText = `현재 참가자: ${data.count}명`;

        const participantList = document.getElementById('participant-list');
        participantList.innerHTML = '';
        data.participants.forEach(participant => {
            const listItem = document.createElement('li');
            listItem.innerText = `ID: ${participant.participantId}`;
            participantList.appendChild(listItem);
        });
    } catch (error) {
        console.error('참가자 정보를 가져오는 중 오류 발생:', error);
    }
}

// 페이지 로드 시 실행
addParticipant().then(() => fetchParticipants());
