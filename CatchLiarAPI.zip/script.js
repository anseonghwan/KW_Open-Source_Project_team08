async function fetchParticipants() {
    try {
        const response = await fetch('https://sonjo9ytcc.execute-api.ap-northeast-2.amazonaws.com/prod/participants', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const rawData = await response.json();
        const data = JSON.parse(rawData.body); // 중첩된 JSON 파싱

        document.getElementById('participant-count').innerText = `현재 참가자: ${data.count}명`;

        const participantList = document.getElementById('participant-list');
        participantList.innerHTML = '';
        data.participants.forEach(participant => {
            const listItem = document.createElement('li');
            listItem.innerText = `ID: ${participant.participantId}`;
            participantList.appendChild(listItem);
        });
    } catch (error) {
        console.error('참가자 정보를 가져오는 중 오류 발생:', error);
        document.getElementById('participant-count').innerText = '참가자 수를 가져오는 데 실패했습니다.';
    }
}

fetchParticipants();
